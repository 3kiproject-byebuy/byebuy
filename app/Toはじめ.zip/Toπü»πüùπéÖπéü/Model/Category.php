<?php


 class Category extends AppModel {




}

?>